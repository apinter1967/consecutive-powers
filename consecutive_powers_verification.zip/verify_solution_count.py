#!/usr/bin/env python3
"""Exact parameter checks for the quintic solution-count theorem.

This checks the numerical inputs of the proof, not the cited Thue-Siegel
principle or the analytically proved gap inequality. Standard library only.
Run: python verify_solution_count.py --outdir checks
"""

import argparse
from fractions import Fraction as F
import hashlib
import json
from math import isqrt
from pathlib import Path
import platform
import sys
import time


def require(condition, message):
    if not condition:
        raise ArithmeticError(message)


def parameters(n):
    special = {
        23: (F(17, 100), F(37, 100), 4, F('0.9747'), F('0.2034')),
        29: (F(9, 50), F(11, 25), 4, F('0.9862'), F('0.0804')),
    }
    if n in special:
        return special[n]
    require(31 <= n <= 181, 'Exponent outside the stated parameter ranges.')
    return F(1, 5), F(9, 20), 3, F('0.9416'), F('0.9868')


def check_row(n):
    a, b, m, u_upper, v_upper = parameters(n)
    g, mu = F(n - 2, 2), F(n, 2)
    lam_squared = 2 * (n + a*a) / (1 - b)**2
    delta = 2 * (b*b - a*a) / ((n + a*a) * (n - 1))
    lower_log_height = 9200
    b_hat = (F(n, 2) + F(14, 5)) / (a*a) + F(7, 5)
    u = lam_squared * (1 + b_hat / lower_log_height)**2 / mu**2
    v = (1 + b_hat / lower_log_height) / (delta * g**m)
    require(0 < a < b < 1 and delta > 0, f'Basic parameters fail for n={n}.')
    require(u < u_upper < 1, f'U bound fails for n={n}.')
    require(v < v_upper < 1, f'V bound fails for n={n}.')
    require(lam_squared < mu**2 < n*n, f'Lambda condition fails for n={n}.')
    return {
        'n': n, 'a': str(a), 'b': str(b), 'm': m,
        'lambda_squared': str(lam_squared), 'delta': str(delta),
        'L': str(lower_log_height), 'B_hat': str(b_hat),
        'U': str(u), 'V': str(v),
        'U_strict_upper_bound': str(u_upper),
        'V_strict_upper_bound': str(v_upper),
        'solution_count_bound': m,
    }


def check_monotonicity():
    # The signs of U' and V' equal the signs of these polynomials.
    # Both are negative and strictly decreasing throughout [31, 181].
    def du(n):
        return 125*n*n - 92714*n - F(185428, 25)

    def dv(n):
        return -93344*n*n - F(4808878, 25)*n + F(4728664, 25)

    du_derivative_upper = 250*181 - 92714
    dv_derivative_upper = -186688*31 - F(4808878, 25)
    require(du(31) < 0 and du_derivative_upper < 0, 'U monotonicity failed.')
    require(dv(31) < 0 and dv_derivative_upper < 0, 'V monotonicity failed.')
    return {
        'interval': [31, 181],
        'U_derivative_sign_polynomial_at_31': str(du(31)),
        'U_sign_polynomial_derivative_upper_bound': str(du_derivative_upper),
        'V_derivative_sign_polynomial_at_31': str(dv(31)),
        'V_sign_polynomial_derivative_upper_bound': str(dv_derivative_upper),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--outdir', default='checks')
    args = parser.parse_args()
    started = time.perf_counter()
    rows = [check_row(n) for n in [23, 29] + list(range(31, 182))]
    monotonicity = check_monotonicity()
    primes = [n for n in range(23, 182)
              if all(n % d for d in range(2, isqrt(n) + 1))]
    require(len(primes) == 34, 'The prime list must have 34 entries.')
    require(sum(n >= 31 for n in primes) == 32, 'Expected 32 primes at least 31.')
    counts = {str(n): check_row(n)['solution_count_bound'] for n in primes}
    total = sum(counts.values())
    require(total == 104, 'The total solution-count bound must equal 104.')
    report = {
        'python': sys.version, 'platform': platform.platform(),
        'arithmetic': 'exact fractions; no floating-point parameter checks',
        'rows': rows, 'monotonicity': monotonicity,
        'remaining_prime_exponents': primes, 'individual_bounds': counts,
        'total_integer_exponent_solution_bound': total,
        'distinct_x_bound_for_arbitrary_integer_exponents': total,
        'elapsed_seconds': time.perf_counter() - started,
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    }
    lines = [
        'Exact verification of the quintic solution-count parameters',
        'All parameter checks use fractions.Fraction.',
        'Two individual rows and all 151 integer rows from 31 to 181 pass.',
        'Both derivative signs are negative throughout the real interval [31, 181].',
        'Bounds: N_23,N_29 <= 4;',
        '        N_n <= 3 for the 32 remaining primes n >= 31.',
        '34 prime exponents; sum of bounds = 2*4 + 32*3 = 104.',
        'The bound also counts distinct x for arbitrary original exponents N >= 3.',
        'Primality of the original exponent is proved in the paper.',
        'The gap inequality and the Thue-Siegel principle are proved or cited in the paper.',
        'Python: ' + sys.version.replace('\n', ' '),
        'Platform: ' + platform.platform(),
        'Script SHA-256: ' + report['script_sha256'],
    ]
    out = Path(args.outdir)
    out.mkdir(parents=True, exist_ok=True)
    (out / 'solution_count_certificate.json').write_text(
        json.dumps(report, indent=2) + '\n', encoding='utf-8')
    (out / 'solution_count_checks.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
