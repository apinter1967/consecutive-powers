#!/usr/bin/env python3
"""Reproduce the explicit quintic reduction in consecutive_powers_note.tex.

Python 3.11+; standard library only. Interval bounds use directed decimal
rounding. The congruence and continued-fraction tests use integers.
The first Laurent block applies to the original exponent. The paper
uses the known exclusions below 23 to prove primality before the sieve.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import sys
import time
from decimal import Decimal, localcontext, ROUND_FLOOR, ROUND_CEILING
from math import isqrt, gcd
from pathlib import Path

PREC = 60
SQRT_SCALE = 10**55
sys.set_int_max_str_digits(0)


def rounded(op, mode):
    with localcontext() as ctx:
        ctx.prec = PREC
        ctx.rounding = mode
        return op()


class I:
    """Closed decimal intervals with outward rounding."""
    def __init__(self, lo, hi=None):
        if isinstance(lo, I):
            self.lo, self.hi = lo.lo, lo.hi
        else:
            self.lo = Decimal(str(lo))
            self.hi = self.lo if hi is None else Decimal(str(hi))
        assert self.lo <= self.hi

    def __add__(self, other):
        other = I(other)
        return I(rounded(lambda: self.lo + other.lo, ROUND_FLOOR),
                 rounded(lambda: self.hi + other.hi, ROUND_CEILING))
    __radd__ = __add__

    def __neg__(self):
        return I(self.hi.copy_negate(), self.lo.copy_negate())

    def __sub__(self, other):
        return self + (-I(other))

    def __rsub__(self, other):
        return I(other) + (-self)

    def __mul__(self, other):
        other = I(other)
        pairs = [(a, b) for a in (self.lo, self.hi)
                 for b in (other.lo, other.hi)]
        low = min(rounded(lambda a=a, b=b: a*b, ROUND_FLOOR)
                  for a, b in pairs)
        high = max(rounded(lambda a=a, b=b: a*b, ROUND_CEILING)
                   for a, b in pairs)
        return I(low, high)
    __rmul__ = __mul__

    def __truediv__(self, other):
        other = I(other)
        assert not other.lo <= 0 <= other.hi
        inv = I(rounded(lambda: Decimal(1)/other.hi, ROUND_FLOOR),
                rounded(lambda: Decimal(1)/other.lo, ROUND_CEILING))
        return self * inv

    def __rtruediv__(self, other):
        return I(other) / self

    def __pow__(self, n):
        assert isinstance(n, int) and n >= 0
        result, a = I(1), self
        while n:
            if n & 1:
                result = result*a
            a = a*a
            n >>= 1
        return result

    def sqrt(self):
        assert self.lo >= 0
        def floor_scaled(d):
            num, den = d.as_integer_ratio()
            return isqrt((num*SQRT_SCALE**2)//den)
        low = floor_scaled(self.lo)
        high = floor_scaled(self.hi) + 1
        return I(Decimal(f'{low}E-55'), Decimal(f'{high}E-55'))

    def ln(self):
        assert self.lo > 0
        return I(log_point(self.lo).lo, log_point(self.hi).hi)

    def bounds(self):
        return [str(self.lo), str(self.hi)]


def log_reduced(r):
    """Log(r), 1 <= r <= 2, via 2*atanh((r-1)/(r+1))."""
    z = (I(r)-1)/(I(r)+1)
    assert 0 <= z.lo and z.hi < Decimal('0.334')
    total = I(0)
    term = z
    # Terms j = 0,...,79; the positive tail starts at degree 161.
    for j in range(80):
        total = total + term/(2*j+1)
        term = term*z*z
    tail = 2*term/(161*(1-z*z))
    return 2*total + I(0, tail.hi)


LOG2 = log_reduced(Decimal(2))


def log_point(x):
    # Exact integer range reduction works even for 10^1000 and beyond.
    num, den = x.as_integer_ratio()
    m = 0
    while num >= 2*den:
        den *= 2
        m += 1
    while num < den:
        num *= 2
        m -= 1
    return m*LOG2 + log_reduced(I(num)/I(den))


def maximum(*args):
    args = [I(a) for a in args]
    return I(max(a.lo for a in args), max(a.hi for a in args))


def laurent_step(lower_p, upper_p, lower_u, rho, mu_num, mu_den):
    """Uniform Theorem 2 bound on lower_p <= n <= upper_p, u >= lower_u."""
    L0 = I(lower_u).ln()
    mu = I(mu_num)/mu_den
    sigma = (1+2*mu-mu*mu)/2
    lam = sigma*I(rho).ln()
    K = 8 + (rho-1)*4*LOG2/(lower_p*L0)
    a10 = K*L0
    a2 = (rho+1)*LOG2
    h = maximum((upper_p/a2+4/a10).ln()+lam.ln()+I('1.81'),
                lam, LOG2/2)
    H = h/lam+1/sigma
    omega = 2*(1+(1+1/(4*H*H)).sqrt())
    theta = (1+1/(4*H*H)).sqrt()+1/(2*H)
    C = mu/(lam**3*sigma)*(omega/6 + I(1)/2*(
        omega**2/9
        + 8*lam*omega*omega.sqrt().sqrt()*theta.sqrt().sqrt()
          /(3*(a10*a2).sqrt()*H.sqrt())
        + I(4)/3*(1/a10+1/a2)*lam*omega/H).sqrt())**2
    Cp = (C*sigma*omega*theta/(lam**3*mu)).sqrt()
    T = h+lam/sigma
    D = Cp*T*T*K*a2
    assert a10.lo >= 1 and a2.lo >= 1
    assert (a10*a2-lam*lam).lo > 0
    # This proves log(D*L)/L is decreasing for L >= L0.
    assert (D*L0).ln().lo > 1
    B = (C*T*T*K*a2 + ((omega*theta).sqrt()*T
         +(D*L0).ln()+I(10).ln())/L0)/2
    return {
        'P': lower_p, 'B': upper_p, 'U': lower_u,
        'rho': rho, 'mu': [mu_num, mu_den],
        'K': K.bounds(), 'h': h.bounds(), 'C': C.bounds(),
        'C_prime': Cp.bounds(), 'upper_bound_interval': B.bounds(),
        'integer_upper_bound': int(B.hi),
    }


def initial_bound():
    c = I(10).ln()/(2*I(3).ln())
    F = I('50.4')*100+c
    assert F.hi < 5042
    assert ((5042+1/I(3).ln()).ln()+I('0.38')).hi < 10
    # For n >= 5042, F(n)/n decreases on both branches of the max:
    # on the logarithmic branch, 2n/(n+delta)-M(n) < 2-10 < 0.
    return {'bound_at_5042': F.bounds(), 'n_le': 5041}


def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    return all(n % d for d in range(3, isqrt(n)+1, 2))


def admissible_primes(max_p):
    """Prime exponents remaining after the known exclusions."""
    return [p for p in range(23, max_p+1) if is_prime(p)]


def good_residues(p, q):
    assert is_prime(q) and (q-1) % p == 0 and q != 2
    pth_powers = {pow(b, p, q) for b in range(q)}
    inverse_16 = pow(16, -1, q)
    good_t = {t for t in pth_powers
              if (pow(t, 4, q)+10*t*t+5)*inverse_16 % q in pth_powers}
    return {a for a in range(q) if pow(a, p, q) in good_t}


def sieve(limit, max_p):
    rows = []
    primes = admissible_primes(max_p)
    for p in primes:
        # Here p is the prime exponent n of the reduced quintic equation.
        candidates = [u for u in range(3, limit+1, 2) if u % 5 and gcd(u, p) == 1]
        steps = []
        for r in range(1, 501):
            q = 2*r*p+1
            if not is_prime(q):
                continue
            good = good_residues(p, q)
            candidates = [u for u in candidates if u % q in good]
            steps.append({'q': q, 'good_residue_count': len(good),
                          'survivor_count': len(candidates)})
            if not candidates:
                break
        assert not candidates, (p, candidates[:20])
        rows.append({'p': p, 'steps': steps, 'survivors': []})
    return rows


def structural_checks():
    from math import gcd
    def factors(n):
        out, q = {}, 2
        while q*q <= n:
            while n % q == 0:
                out[q] = out.get(q, 0)+1
                n //= q
            q += 1
        if n > 1:
            out[n] = 1
        return out
    def part(m, a):
        d = 1
        for q, e in factors(m).items():
            if a % q == 0:
                d *= q**e
        return d
    count = 0
    for k in range(3, 52, 2):
        for x in range(1, 101):
            t = 2*x+1
            b = (x**k+(x+1)**k)//t
            d = part(k, t)
            assert b % d == 0 and gcd(d*t, b//d) == 1
            a = x*x+(x+1)**2
            b = (x**(2*k)+(x+1)**(2*k))//a
            d = part(k, a)
            assert b % d == 0 and gcd(d*a, b//d) == 1
            count += 2
    return count


def continued_fractions(max_p, exponent):
    """Exclude u <= 10^exponent using convergents to 2^(-4/p).

    Decimal transcendental functions only suggest rational endpoints.
    The endpoint inequalities are certified using exact integer powers;
    every subsequent continued-fraction operation uses exact fractions.
    """
    limit = 10**exponent
    places = 8*exponent+50
    S = 10**places
    rows = []
    for p in admissible_primes(max_p):
        with localcontext() as ctx:
            ctx.prec = places+30
            guess = (-4*Decimal(2).ln()/p).exp()
            A = int(guess*S)
        Sp = S**p
        assert 16*A**p < Sp < 16*(A+1)**p
        # Unimodular continued-fraction transformations need no repeated
        # rational simplification: keep the endpoints as integer pairs.
        ln, ld, hn, hd = A, S, A+1, S
        hm2, hm1, qm2, qm1 = 0, 1, 1, 0
        partials, candidates = [], []
        while True:
            al = ln//ld
            ah = hn//hd
            assert al == ah, ('increase interval precision', p)
            partials.append(al)
            h, q = al*hm1+hm2, al*qm1+qm2
            if q > limit**4:
                break
            # For an odd u not divisible by 5, u^4 = 1 (mod 80).
            u = isqrt(isqrt(q)) if q % 80 == 1 else 0
            if u >= 3 and u**4 == q and gcd(u, p) == 1:
                # Check both sides of the approximation to avoid any
                # convention about which parity gives upper convergents.
                assert 16*h**p != u**(4*p)+10*u**(2*p)+5
                candidates.append({'u': str(u), 'v': str(h)})
            hm2, hm1, qm2, qm1 = hm1, h, qm1, q
            ln, ld, hn, hd = hd, hn-al*hd, ld, ln-al*ld
        rows.append({'p': p, 'lower_numerator': str(A),
                     'decimal_places': places, 'partial_quotients': partials,
                     'tested_fourth_power_denominators': candidates,
                     'first_denominator_above_cutoff': str(q)})
    return rows


def direct_laurent_step(B, kappa, ell, r, rho, mu_num, mu_den):
    """Certify Laurent Theorem 1 uniformly for 191 <= n <= B.

    The integer K=ceil(kappa*log(u)) varies with u. All bounds below
    are uniform for log(u) >= 1000*log(10); see the note's proof.
    """
    P = 191
    w0 = I(10**1000).ln()
    kap = I(kappa)
    kp = kap+1/w0
    K0 = kap*w0
    s0 = I(ell)/r+ell/K0
    g0 = I(1)/4-I(ell)/(12*r*s0)
    a = 8+4*(rho-1)*LOG2/(P*w0)
    a2 = (rho+1)*LOG2
    mu = I(mu_num)/mu_den
    sigma = (1+2*mu-mu*mu)/2
    b0 = ((4*r/K0+B*s0)/2).ln()+I('1.5')+(K0.ln()+2)/K0
    c0 = (sigma*ell-1)*I(rho).ln()-b0
    margin = (kap*c0-2*(kp*ell*w0).ln()/w0
              -g0*ell*(r*a+kp*s0*a2)-3/w0)
    M0 = maximum(ell*kp*s0/8, I(ell*r)/(2*P*w0))
    logterm = (10*M0*w0).ln()
    Q = (mu*kp*ell*I(rho).ln()+(logterm+1)/w0)/2
    assert 2 <= r < P <= B and ell >= 2
    assert K0.lo >= 2 and (K0*ell).lo >= 10
    assert c0.lo > 0 and g0.lo > 0
    assert (kp*ell*w0).ln().lo > 1
    assert logterm.lo > 1 and (2*P*w0-logterm).lo > 0
    assert (2*P*w0).lo > 1
    assert margin.lo > 0
    return {'P': P, 'B': B, 'log_u_min': w0.bounds(),
            'kappa': str(kappa), 'ell': ell, 'r': r, 'rho': rho,
            'mu': [mu_num, mu_den], 'K0': K0.bounds(),
            's0': s0.bounds(), 'g0': g0.bounds(), 'a': a.bounds(),
            'b0': b0.bounds(), 'c0': c0.bounds(), 'M0': M0.bounds(),
            'positivity_margin': margin.bounds(),
            'upper_bound_interval': Q.bounds()}


def direct_laurent_chain():
    specifications = [(271, '42', 6, 22, 16),
                      (199, '44', 5, 23, 19),
                      (193, '43.3', 5, 23, 19),
                      (191, '43.2', 5, 23, 19)]
    rows = []
    available = 271
    for B, kappa, ell, r, rho in specifications:
        assert B == available
        row = direct_laurent_step(B, kappa, ell, r, rho, 3, 5)
        available = max(admissible_primes(int(Decimal(
            row['upper_bound_interval'][1]))))
        row['next_admissible_bound'] = available
        rows.append(row)
    assert available == 181
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--outdir', default='.')
    parser.add_argument('--limit', type=int, default=1_000_000)
    parser.add_argument('--cf-exponent', type=int, default=1000)
    args = parser.parse_args()
    if not __debug__:
        parser.error('Run without -O so the certificate assertions are active.')
    assert args.limit >= 1_000_000, 'The note requires at least 10^6.'
    started = time.perf_counter()
    report = {'python': sys.version, 'platform': platform.platform(),
              'interval_precision': PREC,
              'exponent_scope': 'arbitrary n until n < 479; prime n thereafter',
              'initial_bound': initial_bound()}
    first = []
    B = 5041
    for _ in range(8):
        row = laurent_step(479, B, 3, 16, 1, 3)
        first.append(row)
        B = row['integer_upper_bound']
        if B < 479:
            break
    assert B < 479 < 23**2
    report['least_possible_prime_divisor'] = 23  # literature input
    report['original_exponent_strict_upper_bound_before_primality'] = 479
    report['first_laurent_chain'] = first
    sieve_bound = max(admissible_primes(478))
    assert sieve_bound == 467
    report['exponent_bound_before_sieve'] = sieve_bound
    report['structural_identity_checks'] = structural_checks()
    report['sieve_limit'] = args.limit
    report['sieve'] = sieve(args.limit, sieve_bound)
    second = []
    B = sieve_bound
    for _ in range(8):
        row = laurent_step(331, B, args.limit+1, 18, 12, 25)
        second.append(row)
        B = row['integer_upper_bound']
        if B < 331:
            break
    assert B < 331
    report['second_laurent_chain'] = second
    intermediate_bound = max(admissible_primes(330))
    assert intermediate_bound == 317
    report['exponent_bound_before_cf'] = intermediate_bound
    assert args.cf_exponent >= 1000
    report['continued_fraction_exponent'] = args.cf_exponent
    report['continued_fractions'] = continued_fractions(intermediate_bound,
                                                       args.cf_exponent)
    third = []
    B = intermediate_bound
    for _ in range(8):
        row = laurent_step(277, B, 10**args.cf_exponent, 19, 27, 50)
        third.append(row)
        B = row['integer_upper_bound']
        if B < 277:
            break
    assert B < 277
    report['third_laurent_chain'] = third
    report['exponent_bound_before_direct_laurent'] = 271
    report['direct_laurent_chain'] = direct_laurent_chain()
    report['final_exponent_bound'] = 181
    report['remaining_exponents'] = admissible_primes(181)
    assert len(report['remaining_exponents']) == 34
    report['certified_partial_quotients'] = sum(
        len(row['partial_quotients']) for row in report['continued_fractions'])
    report['largest_sieve_multiplier'] = max(
        (step['q']-1)//(2*row['p'])
        for row in report['sieve'] for step in row['steps'])
    report['elapsed_seconds'] = time.perf_counter()-started
    report['script_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    out = Path(args.outdir)
    out.mkdir(parents=True, exist_ok=True)
    (out/'consecutive_powers_certificate.json').write_text(
        json.dumps(report, indent=2)+'\n', encoding='utf-8')
    lines = [
        'Exact verification of the quintic prime-exponent reduction',
        'Every prime divisor is at least 23 by the cited literature.',
        'All logarithm and square-root bounds use outward intervals.',
        'Initial bound: n <= 5041.',
        'First Laurent chain (P = 479, U = 3):',
    ]
    for row in first:
        lines.append(f"  B={row['B']}: n < {row['upper_bound_interval'][1]}")
    lines += ["The first block gives n < 479 < 23^2, so the original exponent is prime.",
              f"Consequently n <= {sieve_bound}; {len(report['sieve'])} admissible prime exponents sieved.",
              f"For every such exponent all admissible 3 <= u <= {args.limit} were excluded.",
              'Second Laurent chain (P = 331):']
    for row in second:
        lines.append(f"  B={row['B']}: n < {row['upper_bound_interval'][1]}")
    lines += [f'Consequently n <= {intermediate_bound}.',
              f"Continued fractions exclude u <= 10^{args.cf_exponent} for all {len(report['continued_fractions'])} tested prime exponents.",
              f"Certified partial quotients: {report['certified_partial_quotients']}.",
              f"Largest sieve multiplier: {report['largest_sieve_multiplier']}.",
              'Third Laurent chain (P = 277):']
    for row in third:
        lines.append(f"  B={row['B']}: n < {row['upper_bound_interval'][1]}")
    lines += ['Consequently n <= 271.',
              'Direct Laurent Theorem 1 chain (P = 191, log(u) > 1000 log(10)):']
    for row in report['direct_laurent_chain']:
        lines.append(f"  B={row['B']}, kappa={row['kappa']}, ell={row['ell']}, "
                     f"r={row['r']}, rho={row['rho']}: "
                     f"margin > {row['positivity_margin'][0]}; "
                     f"n < {row['upper_bound_interval'][1]}; "
                     f"next admissible bound {row['next_admissible_bound']}")
    lines += ['Consequently n <= 181.',
              f"Remaining prime exponents ({len(report['remaining_exponents'])}): "
              + ', '.join(map(str, report['remaining_exponents'])),
              'Existence for the remaining exponents is open in this argument.',
              f"Elapsed seconds: {report['elapsed_seconds']:.3f}",
              'Python: '+sys.version.replace('\n', ' '),
              'Platform: '+platform.platform(),
              'Script SHA-256: '+report['script_sha256']]
    text = '\n'.join(lines)+'\n'
    (out/'consecutive_powers_checks.txt').write_text(text, encoding='utf-8')
    print(text)


if __name__ == '__main__':
    main()
