Verification package for “Explicit exponent bounds for sums of consecutive powers”
Ákos Pintér

Run both programs with Python 3.11 or later and normal assertions enabled.

    python verify_consecutive_powers.py --outdir checks
    python verify_solution_count.py --outdir checks

Both programs use the standard library and work offline. Each produces a
JSON certificate and a plain-text report. Full runs record the Python version,
platform, elapsed time (in the certificate), and SHA-256 digest of the script.

Mathematical scope

The input is a positive integer solution of x^5 + (x+1)^5 = y^n, n >= 3.
For every prime divisor p of n, (x,x+1,y^(n/p)) is a primitive solution
of A^5+B^5=C^p. The results cited in the paper, including the unconditional
part of Stoll's theorem, imply p >= 23. They also yield gcd(y,5n)=1.
In particular the descent gives 2x+1=u^n and
u^(4n)+10u^(2n)+5 = 16v^n with the original n.

The initial bound and the first block of Laurent estimates apply to every
such integer n. They give n < 479 < 23^2, so n itself is prime. This is
the step that makes it sufficient to consider only primes subsequently.
All reported bounds are unconditional.

Exponent and size verification

1. The preliminary bound is n <= 5041. Four applications of Laurent's
   Theorem 2 give n < 479, hence n is a prime at most 467.
2. A congruence sieve tests all 83 primes 23 <= n <= 467 and excludes odd
   3 <= u <= 10^6 with gcd(u,5n)=1. The next Laurent block gives n <= 317.
3. For the 58 primes 23 <= n <= 317, the program certifies the continued
   fractions of 2^(-4/n) through denominator 10^4000. It checks 450795
   partial quotients, including the first convergent beyond the cutoff
   for each n. The only candidate with denominator u^4, u >= 3 odd and
   coprime to 5n, is 80/81 for n=223. Its numerator is even and the
   program also checks the quintic identity directly. Thus u > 10^1000.
4. A third Laurent block gives n <= 271. Four applications of Laurent's
   Theorem 1 then leave the 34 primes 23 <= n <= 181. As 2x+1 = u^n,
   one obtains x > (10^23000-1)/2.

The sieve and convergent tests use integer arithmetic. Decimal approximations
suggest endpoint numerators A; the inequalities 16A^n < S^n < 16(A+1)^n
with S=10^8050 certify the endpoints. The logarithmic estimates use directed
decimal intervals, a range-reduced series with a rigorous tail bound for
logarithms, and integer square roots. In the exponent certificate, p is the
prime exponent of a sieve or continued-fraction row, while P, B, U are the
lower and upper exponent bounds and the lower bound on u in a Laurent step.

Solution count

The second program checks the rational parameters of the Thue–Siegel
argument for n=23,29 and throughout the integer range 31 <= n <= 181.
It additionally checks the derivative signs used in the proof over the
whole real interval [31,181]. In this certificate U and V are the two
rational quantities from the solution-count proof. Their strict upper
bounds yield at most four solutions for each of 23 and 29, and at most
three for each of the 32 larger primes. The resulting upper bound is
2*4 + 32*3 = 104 triples with arbitrary integer exponent n >= 3.

File list

    verify_consecutive_powers.py          Exponent and size verification
    consecutive_powers_certificate.json   Interval, modular and continued-fraction data
    consecutive_powers_checks.txt         Execution report
    verify_solution_count.py              Exact rational parameter checks
    solution_count_certificate.json       Individual and aggregate count bounds
    solution_count_checks.txt             Execution report

The cited theorems, the valuation descent, the gap argument and the exclusion
of composite exponents are justified in the manuscript. The programs verify
the finite calculations. Existence in the remaining 34 cases is unresolved
by this argument.
